"""
# traffic_environment.py
# 12/2/2020 created by
#
# Here the TrafficEnvironment Class defined with which a traffic simulation model is described, highly correlating to
# SUMO the platform.
"""

import traci
import networkx as nx
import random


class NetGameEnvironment:
    def __init__(self, net_game_setting):
        self.net_game_setting = net_game_setting
        self.A_mat = net_game_setting['A_mat']
        print('初始化仿真环境……')

    def simulation_step(self):
        """# 执行一步仿真"""
        traci.simulationStep()

    # def get_A_mat(self):
    #     A_mat = self.net_game_setting['A_mat']
    #     return A_mat

    def net_work(self):
        nodelist = self.net_game_setting['id_list']
        edgelist = self.net_game_setting['edge_list']
        G = nx.Graph()  # 创建空的无向图
        # 增加节点
        G.add_node(1)  # 每次增加一个节点
        G.add_nodes_from(nodelist)  # iterable container
        # print(list(G.nodes))    # 获取所有节点 [1, 3, 5, 8, 6, 2]
        # 增加edges
        G.add_edges_from(edgelist)
        # nx.draw(G, with_labels=True)
        # plt.show()
        # print(list(G.adj[1]))
        return G



    # def retrieve_state_by(self, current):
    #     """# retrieve state value"""
    #     if state_type == 'queue_count' or state_type == 'queue_count_edge':  # 边 上的排队长度
    #         return self.__retrieve_queue_count_on_edge(edge_id=paras)
    #     else:
    #         raise Exception('there is no such bizarre state type')



    # def execute_action_by(self, tls_id, action, action_config):
    #     """execute action"""
    #     if action_config['types'][action] == 'keep':  # 什么也不做
    #         pass
    #     elif action_config['types'][action] == 'switch':  # 切换到下一相位，不改变相序
    #         self.__execute_action_switch_to_next_phase(tls_id=tls_id)
    #     else:
    #         raise Exception('there is no such action')


    def retrieve_reward_netgame_by(self, all_netgame_agents_z, netgame_neighbor_list, netgame_agent_id):
        """# retrieve reward value"""
        reward = 0
        for netgame_agent_neighbor in netgame_neighbor_list:
            reward += all_netgame_agents_z[netgame_agent_id].T * self.A_mat * all_netgame_agents_z[netgame_agent_neighbor]
        return reward[0, 0]       #取reward矩阵中的值



