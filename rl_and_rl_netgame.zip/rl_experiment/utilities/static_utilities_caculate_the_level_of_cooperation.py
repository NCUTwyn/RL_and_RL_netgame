def calculate_the_level_of_netgame_cooperation(all_netgame_agents_current_actions):
    cooperation_value_list = []
    for key, val in all_netgame_agents_current_actions.items():
        if val == '合作':
            cooperation_value = 1
            cooperation_value_list.append(cooperation_value)
        if val == '背叛':
            cooperation_value = 0
            cooperation_value_list.append(cooperation_value)
    the_level_of_netgame_cooperation = sum(cooperation_value_list)/len(all_netgame_agents_current_actions)
    return the_level_of_netgame_cooperation

