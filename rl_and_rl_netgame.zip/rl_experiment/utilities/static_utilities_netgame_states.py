import random


def get_all_netgame_agents_states_by(netgame_agents_list, all_netgame_agents_current_actions):
    """读取所有Agent的状态"""
    all_netgame_agents_current_states = {}
    state_val = ()
    for name, agent in netgame_agents_list.items():
        state_val = (all_netgame_agents_current_actions[name],)
        all_netgame_agents_current_states[name] = state_val
    return all_netgame_agents_current_states


def init_NS():
    if random.random() > 0.5:
        state = 1
    else:
        state = 0
    return state


def init_NS_netgame(netgame_agents_list):
    all_netgame_agents_init_states = {}
    init_q_table = ()
    for name, agent in netgame_agents_list.items():
        init_q_table = (init_NS(),)
        all_netgame_agents_init_states[name] = init_q_table
    return all_netgame_agents_init_states
