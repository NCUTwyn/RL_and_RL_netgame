def get_all_netgame_agents_learning_type(netgame_agents_list):
    """get all agents' learning model type"""
    all_netgame_agents_learning_type = {}
    for netgame_name, netgame_agent in netgame_agents_list.items():
        all_netgame_agents_learning_type[netgame_name] = netgame_agent.get_learning_model_type()
    return all_netgame_agents_learning_type


def get_agent_neighbors_q_values(neighbors_names, q_values):
    """获得agent的所有邻居的Q值"""
    neighbors_q_values = []
    for neighbor in neighbors_names:
        neighbors_q_values.append(q_values[neighbor])
    return neighbors_q_values


def get_agent_neighbors_action_values(neighbors_names, netgame_action_values):
    """获得agent的所有邻居的Q值"""
    neighbors_action_values = []
    for neighbor in neighbors_names:
        neighbors_action_values.append(netgame_action_values[neighbor])
    return neighbors_action_values


def get_sum_agent_neighbors_q_values(neighbors_names, neighbors_q_values, neighbors_action_values):
    sum_q = 0
    for neighbor in neighbors_names:
        sum_q =+ neighbors_q_values[neighbor] * neighbors_action_values[neighbor]
    return sum_q


def get_all_netgame_agents_q_by(pre_states, actions, netgame_agents_list):
    """ 依据state和action得到每个Agent的Q值"""
    all_netgame_agents_q = {}
    for name, netgame_agent in netgame_agents_list.items():
        all_netgame_agents_q[name] = netgame_agent.get_q_value_by(state=pre_states[name], action=actions[name])
    return all_netgame_agents_q

