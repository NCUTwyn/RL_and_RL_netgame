def get_all_agents_learning_type(agents_list):
    """get all agents' learning model type"""
    all_agents_learning_type = {}
    for name, agent in agents_list.items():
        all_agents_learning_type[name] = agent.get_learning_model_type()
    return all_agents_learning_type


def get_agent_neighbors_q_values_list(neighbors_names, q_values):
    """获得agent的所有邻居的Q值"""
    neighbors_q_values = []
    for neighbor in neighbors_names:
        neighbors_q_values.append(q_values[neighbor])
    return neighbors_q_values


def get_agent_neigbors_q_values_dic(neighbors_names, q_values):
    neighbors_q_values = {}
    for neighbor in neighbors_names:
        neighbors_q_values[neighbor] = q_values[neighbor]
    return neighbors_q_values


def get_agent_neighbors_action_values(neighbors_names, netgame_action_values):
    """获得agent的所有邻居的Q值"""
    neighbors_action_values = []
    for neighbor in neighbors_names:
        neighbors_action_values.append(netgame_action_values[neighbor])
    return neighbors_action_values


def get_agent_neighbors_action_switch_to_values(neighbors_names, netgame_action_values):
    neighbors_action_values = {}
    for neighbor in neighbors_names:
        if netgame_action_values[neighbor] == '合作':
            neighbors_action_values[neighbor] = 1
        else:
            neighbors_action_values[neighbor] = 0    #即'背叛'
    return neighbors_action_values


def get_sum_agent_neighbors_q_values(neighbors_names, neighbors_q_values, neighbors_action_values):
    sum_q = 0
    for neighbor in neighbors_names:
        sum_q =+ neighbors_q_values[neighbor] * neighbors_action_values[neighbor]
    return sum_q


def get_all_agents_q_by(pre_states, actions, agents_list):
    """ 依据state和action得到每个Agent的Q值"""
    all_agents_q = {}
    for name, agent in agents_list.items():
        all_agents_q[name] = agent.get_q_value_by(state=pre_states[name], action=actions[name])
    return all_agents_q

