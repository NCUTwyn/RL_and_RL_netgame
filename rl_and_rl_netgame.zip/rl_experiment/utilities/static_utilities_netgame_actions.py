import numpy as np


def get_all_netgame_agents_actions_by(netgame_agents_states, netgame_agents_list):
    """获取指定状态下agents选择的动作"""
    all_netgame_agent_selected_actions = {}
    for name, netgame_agent in netgame_agents_list.items():
        netgame_action_selection_model = netgame_agent.get_action_selection_model()  # 获得该Agent的动作类型
        #
        if netgame_action_selection_model == 'eps_greedy':
            action = netgame_agent.select_action_eps_greedy(state=netgame_agents_states[name])  # 参数：状态
        #
        elif netgame_action_selection_model == 'UCB':  #
            action = netgame_agent.select_action_ucb(state=netgame_agents_states[name])
        #
        elif netgame_action_selection_model == 'Boltzmann': # Softmax方法
            action = netgame_agent.select_action_boltzmann(state=netgame_agents_states[name])
        else:
            raise Exception('there is no such a selection model')
        #
        all_netgame_agent_selected_actions[name] = action

    return all_netgame_agent_selected_actions  # 返回

def get_all_netgame_agents_z_by(netgame_agents_action):
    all_netgame_agents_z = {}
    for key, val in netgame_agents_action.items():
        if val == '合作':
            z = np.mat(([1], [0]))
            all_netgame_agents_z[key] = z
        if val == '背叛':
            z = np.mat(([0], [1]))
            all_netgame_agents_z[key] = z
    return all_netgame_agents_z


# def execute_actions_in_environment(environment, actions_list, agents_list):
#     """在环境中执行动作"""
#     for agent_id, action_name in actions_list.items():
#         environment.execute_action_by(tls_id=agents_list[agent_id].get_tls_id(), action=action_name,
#                                       action_config=agents_list[agent_id].get_action_config())
