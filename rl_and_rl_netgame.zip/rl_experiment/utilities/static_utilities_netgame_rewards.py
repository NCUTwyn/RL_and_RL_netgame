def get_all_netgame_agents_rewards_by(all_netgame_agents_z, netgame_agents_list,netgame_environment):
    all_netgame_agents_rewards_netgame = {}
    for netgame_agent_id, netgame_agent in netgame_agents_list.items():
        netgame_neighbors = netgame_agent.get_neighbors()
        all_netgame_agents_rewards_netgame[netgame_agent_id] = get_netgame_reward(all_netgame_agents_z=all_netgame_agents_z,
                                                                                  netgame_neighbors=netgame_neighbors,
                                                                                  netgame_environment=netgame_environment,
                                                                                  netgame_agent_id=netgame_agent_id)
    return all_netgame_agents_rewards_netgame


def get_netgame_reward(all_netgame_agents_z, netgame_neighbors,netgame_environment,netgame_agent_id):
    '''netgame的reward值'''
    return netgame_environment.retrieve_reward_netgame_by(all_netgame_agents_z=all_netgame_agents_z,
                                                          netgame_neighbor_list=netgame_neighbors,
                                                          netgame_agent_id=netgame_agent_id)


# def get_reward_single(environment, reward_config):
#     """single类型的reward值"""
#     reward_name = reward_config['names']
#     return environment.retrieve_reward_by(reward_type=reward_config['types'][reward_name],
#                                           paras=reward_config['retrieve_para'][reward_name])
#
#
# def get_reward_single_qualitative(environment, reward_config):
#     """single类型，返回定性评价值"""
#     return -99
#
#
# def get_reward_weighted(environment, reward_config):
#     """weighted类型，返回加权reward值"""
#     return -99
#
#
# def get_reward_compound(environment, reward_config):
#     """weighted类型，返回加权reward值"""
#     return -99
