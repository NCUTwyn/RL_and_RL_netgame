import sys
import os
import traci
import traci.constants as tc
import pandas as pd
import numpy as np
import pandas as pd

# 仿真模型
# sumoCmd = ["sumo", "-c", "C:/Users/10539/Documents/My_SUMO/4RL-test/simple6nodes.sumocfg"]
sumoCmd = ["sumo-gui", "-c", "D:/研三实验/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/RL_experiments-main/rl_experiment/3nodes/3nodes.sumocfg", '--start']
##--------------------------初始化仿真 traci -----------------------------
traci.start(sumoCmd)
step = 0  # 设置步长计数
t = 0
t_2 = 0
t_3 = 0
y = [0, 0, 0, 0, 0, 0, 0, 0]

J1 = ["gneE8", "gneE7", "gneE3", "gneE2", "gneE5", "gneE4", "gneE1", "gneE0"]
J2 = ["gneE12", "gneE11", "gneE10", "gneE9", "gneE15", "gneE14", "gneE2", "gneE3"]
J3 = ["gneE19", "gneE17", "gneE18", "gneE16", "gneE21", "gneE20", "gneE9", "gneE10"]


def queue_count(j):
    queue = [0, 0, 0, 0, 0, 0, 0, 0]
    for i in range(0, 8):
        queue[i] = traci.edge.getLastStepHaltingNumber(j[i])
    return queue


def n_s_pressure(j,queue):
    phase_n_s = (queue[0] - queue[5]) + (queue[4] - queue[1])
    return phase_n_s


def w_e_pressure(j,queue):
    phase_w_e = (queue[6] - queue[3]) + (queue[2] - queue[7])
    return phase_w_e

# ------------------------------  开始进行仿真  ------------------------------------------
# Run a simulation until all vehicles have arrived
while traci.simulation.getMinExpectedNumber() > 0:
    # print("step", step)
    step += 1
    traci.simulationStep()
    y = np.row_stack((y, queue_count(J1)))
    e = pd.DataFrame(columns=None, data=y)
    print(e)
    e.to_csv('D:/研三实验/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/RL_experiments-main/rl_experiment/3nodes/queue_count1.csv')
    t=t+1
    queue = queue_count(J1)
    phase_n_s = n_s_pressure(J1, queue)         # 南北向排队压力
    phase_w_e = w_e_pressure(J1, queue)         # 东西向排队压力
    phasetime = traci.trafficlight.getPhaseDuration('gneJ0')
    print(t)
    if t > phasetime:
        next_phase = max((phase_n_s), (phase_w_e))
        if next_phase == phase_w_e:
            traci.trafficlight.setPhase('gneJ0', 2)
        else:
            traci.trafficlight.setPhase('gneJ0', 0)
        t = 0

    t_2 = t_2+1
    queue_2 = queue_count(J2)
    phase_n_s = n_s_pressure(J2, queue_2)         # 南北向排队压力
    phase_w_e = w_e_pressure(J2, queue_2)         # 东西向排队压力
    phasetime = traci.trafficlight.getPhaseDuration('J2')
    print(t)
    if t_2 > phasetime:
        next_phase = max((phase_n_s), (phase_w_e))
        if next_phase == phase_w_e:
            traci.trafficlight.setPhase('J2', 2)
        else:
            traci.trafficlight.setPhase('J2', 0)
        t_2 = 0

    t_3 = t_3+1
    queue_3 = queue_count(J3)
    phase_n_s = n_s_pressure(J3, queue_3)         # 南北向排队压力
    phase_w_e = w_e_pressure(J3, queue_3)         # 东西向排队压力
    phasetime = traci.trafficlight.getPhaseDuration('J3')
    print(t)
    if t_2 > phasetime:
        next_phase = max((phase_n_s), (phase_w_e))
        if next_phase == phase_w_e:
            traci.trafficlight.setPhase('J3', 2)
        else:
            traci.trafficlight.setPhase('J3', 0)
        t_2 = 0




    # 设定最大压力方向为下一阶段
    #print(total)
traci.close()
