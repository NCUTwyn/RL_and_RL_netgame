import pickle
f = open('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31\RL_experiments-main/rl_experiment/test_data.pickle','rb+')
info = pickle.load(f)
print(info)