import pandas as pd

df = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31'
                   '/RL_experiments-main/rl_experiment/3nodes/analysis_data/eps/e2det_gneE1_0.xlsx', index_col='meanSpeed')
print(df)