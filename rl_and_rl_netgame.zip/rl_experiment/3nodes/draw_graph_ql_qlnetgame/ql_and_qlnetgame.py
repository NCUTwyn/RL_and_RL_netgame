import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

#ql_eps
# data1 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                     'RL_experiments-main/rl_experiment/3nodes/analysis_data_ql/eps/'
#                       'e2det_gneE15_1.xlsx',usecols=['meanSpeed'])
# data2=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_eps.xlsx',usecols=['meanSpeed'])
# data3=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_UCB.xlsx',usecols=['meanSpeed'])
# data4=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_Boltzmann.xlsx',usecols=['meanSpeed'])

#ql_Boltzmann
# data1 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                     'RL_experiments-main/rl_experiment/3nodes/analysis_data_ql/Boltzmann/'
#                       'e2det_gneE15_1.xlsx',usecols=['meanSpeed'])
# data2=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_eps.xlsx',usecols=['meanSpeed'])
# data3=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_UCB.xlsx',usecols=['meanSpeed'])
# data4=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_Boltzmann.xlsx',usecols=['meanSpeed'])

# #ql_UCB
# data1 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                     'RL_experiments-main/rl_experiment/3nodes/analysis_data_ql/UCB/'
#                       'e2det_gneE15_1.xlsx',usecols=['meanOccupancy'])
# data2=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_eps.xlsx',usecols=['meanOccupancy'])
# data3=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_UCB.xlsx',usecols=['meanOccupancy'])
# data4=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE15_1_Boltzmann.xlsx',usecols=['meanOccupancy'])

data1 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                    'RL_experiments-main/rl_experiment/3nodes/analysis_data_ql/Boltzmann/'
                      'e2det_gneE15_1.xlsx',usecols=['meanSpeed'])
data2 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                    'RL_experiments-main/rl_experiment/3nodes/analysis_data_ql/eps/'
                      'e2det_gneE15_1.xlsx',usecols=['meanSpeed'])
data3 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                    'RL_experiments-main/rl_experiment/3nodes/analysis_data_ql/UCB/'
                      'e2det_gneE15_1.xlsx',usecols=['meanOccupancy'])

data4=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                  'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
                  'e2det_gneE15_1_eps.xlsx',usecols=['meanSpeed'])
data5=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                  'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
                  'e2det_gneE15_1_UCB.xlsx',usecols=['meanSpeed'])
data6=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                  'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
                  'e2det_gneE15_1_Boltzmann.xlsx',usecols=['meanSpeed'])

x1=np.arange(0, 1020, 60)
y1=data1
x2=np.arange(0, 1020, 60)
y2=data2
x3=np.arange(0, 1020, 60)
y3=data3
x4=np.arange(0, 1020, 60)
y4=data4
x5=np.arange(0, 1020, 60)
y5=data5
x6=np.arange(0, 1020, 60)
y6=data6

plt.plot(x1, y1, color='blue', linestyle='-', linewidth=2, marker='o', ms='6', mec='blue', mfc='blue',
         label='ql_Boltzmann')
#plt.plot(x1, y1, 'om')
plt.xlim(0, 960)
plt.ylim(0, 20)
plt.plot(x2, y2, color='yellow', linestyle='-', linewidth=2, marker='o', ms='6', mec='yellow', mfc='yellow',
         label='ql_eps')
plt.xlim(0, 960)
plt.ylim(0, 20)
plt.plot(x3, y3, color='red', linestyle='-', linewidth=2, marker='o', ms='6', mec='red', mfc='red',
         label='ql_UCB')
plt.xlim(0, 960)
plt.ylim(0, 20)
plt.plot(x4, y4, color='orange', linestyle='-', linewidth=2, marker='o', ms='6', mec='orange', mfc='orange',
         label='ql_netgame_eps')
plt.xlim(0, 960)
plt.ylim(0, 20)
plt.plot(x5, y5, color='green', linestyle='-', linewidth=2, marker='o', ms='6', mec='green', mfc='green',
         label='ql_netgame_UCB')
plt.xlim(0, 960)
plt.ylim(0, 20)
plt.plot(x6, y6, color='black', linestyle='-', linewidth=2, marker='o', ms='6', mec='black', mfc='black',
         label='ql_netgame_Boltzmann')
plt.xlim(0, 960)
plt.ylim(0, 20)
plt.title('ql_and_qlnetgame_constract')

plt.xlabel('time')
plt.ylabel('meanOccupancy')

plt.legend(loc=4) #图例的位置

plt.show()