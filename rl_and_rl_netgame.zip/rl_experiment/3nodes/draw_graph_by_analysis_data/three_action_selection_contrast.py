import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

#middle_cross_gneE15_1
data1 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                    'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
                      'e2det_gneE15_1_Boltzmann.xlsx',usecols=['meanSpeed'])
data2=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                  'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
                  'e2det_gneE15_1_eps.xlsx',usecols=['meanSpeed'])
data3=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
                  'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
                  'e2det_gneE15_1_UCB.xlsx',usecols=['meanSpeed'])

# #left_cross_gneE5_1
# data1 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                     'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                       'e2det_gneE5_1_Boltzmann.xlsx',usecols=['meanSpeed'])
# data2=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE5_1_eps.xlsx',usecols=['meanSpeed'])
# data3=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE5_1_UCB.xlsx',usecols=['meanSpeed'])

# #right_cross_gneE21_1
# data1 = pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE21_1_Boltzmann.xlsx',usecols=['meanSpeed'])
# data2=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE21_1_eps.xlsx',usecols=['meanSpeed'])
# data3=pd.read_excel('F:/研一实验/RL_experiments-main 2.7/RL_experiments-main (6)1.31(1)/RL_experiments-main (6)1.31/'
#                   'RL_experiments-main/rl_experiment/3nodes/draw_graph_by_analysis_data/'
#                   'e2det_gneE21_1_UCB.xlsx',usecols=['meanSpeed'])

x1=np.arange(0, 1020, 60)
y1=data1
x2=np.arange(0, 1020, 60)
y2=data2
x3=np.arange(0, 1020, 60)
y3=data3
plt.plot(x1, y1, color='steelblue', linestyle='-', linewidth=2, marker='o', ms='6', mec='steelblue', mfc='steelblue',
         label='Boltzmann')
#plt.plot(x1, y1, 'om')
plt.xlim(0, 960)
plt.ylim(0, 12)
plt.plot(x2, y2, color='orange', linestyle='-', linewidth=2, marker='o', ms='6', mec='darkorange', mfc='darkorange',
         label='eps')
plt.xlim(0, 960)
plt.ylim(0, 12)
plt.plot(x3, y3, color='forestgreen', linestyle='-', linewidth=2, marker='o', ms='6', mec='g', mfc='g',
         label='UCB')
plt.xlim(0, 960)
plt.ylim(0, 12)
plt.title('three_action_selection_contrast')

plt.xlabel('time')
plt.ylabel('meanSpeed')

plt.legend(loc=4) #图例的位置

plt.show()