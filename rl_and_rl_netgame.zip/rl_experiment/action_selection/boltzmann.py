import numpy as np
import pandas as pd


def boltzmann(**kwargs):
    """Boltzmann or Softmax equation"""
    state = kwargs['state']
    q_table = kwargs['q_table']
    temperature = kwargs['temperature']
    #
    q_state_action = q_table.loc[state, :]  # loc是获取一列的值:取q_table的observation行，所有列
    print('q_state_action:', q_state_action)
    e_q_state_action = np.exp(q_state_action / temperature)  #
    print('e_q_state_action:', e_q_state_action)
    e_q_state_action_sum = np.sum(e_q_state_action)
    print('e_q_state_action_sum:', e_q_state_action_sum)
    #
    probability_actions = np.true_divide(e_q_state_action, e_q_state_action_sum).fillna(1)
    print('probability_actions:', probability_actions)
    #dropna(axis=0)
    action_selected = np.random.choice(
        q_state_action[(q_state_action == np.random.choice(q_state_action, p=probability_actions))].index)

    print('action_selected:', action_selected)
    return action_selected
